
<html>
<body>
<script type="text/javascript">
    function ShowLoading(e) {
        var div = document.createElement('div');
        var img = document.createElement('img');
        img.src = 'img/loading.gif';
        div.innerHTML = "Syncing account... Please wait.<br />";
        div.style.cssText = 'position: fixed; top: 10%; left: 40%; z-index: 5000; width: 422px; text-align: center; background: #FFFFFF; border: 0px solid #000';
        div.appendChild(img);
        document.body.appendChild(div);
        return true;
    }
</script>
</body>
<?php
include("/usr/local/cpanel/php/cpanel.php");  // Instantiate the CPANEL object.
$cpanel = new CPANEL();                       // Connect to cPanel - only do this once.
print $cpanel->header( "IMAPSYNC GUI" );      // Add the header.
?>
This tool will allow you to copy/synchronize a complete mailbox from a remote host to another account locally.
<hr />
<?php
    if (!isset($_POST['button']))
    {
?>

<h2>Select Source Mailbox</h2>
<br /><label for="user1">Login</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"> </i></span>
<input type="text" class="form-control input-lg" id="user1" name="user1" tabindex="1" placeholder="Enter email address">
</div>
<label for="password1">Password</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input type="password" class="form-control input-lg" id="password1" name="password1" tabindex="2" placeholder="Enter password">
</div>
<label for="host1">Server</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-cloud"></i></span>
<input data-toggle="tooltip" data-placement="bottom" list="servers1" type="text" class="form-control input-lg" id="host1" name="host1" tabindex="3" placeholder="Enter imap source server name or IP address">
<datalist id="servers1">
<option value="imap.gmail.com">
<option value="outlook.office365.com">
<option value="imap.mail.yahoo.com">
</datalist>
</div>
<hr />
<form method="post" onsubmit="ShowLoading()">
<h2>Select Destination Mailbox</h2>
<br /><label for="user2">Email Address</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
<input type="text" class="form-control input-lg" id="user2" name="user2" tabindex="6" placeholder="Enter email address">
</div>
<label for="password2">Password</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
<input type="password" class="form-control input-lg" id="password2" name="password2" tabindex="7" placeholder="Enter password">
</div>
<label for="host2">Server</label>
<div class="input-group form-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-cloud"></i></span>
<input data-toggle="tooltip" data-placement="bottom" list="servers2" type="text" class="form-control input-lg" id="host2" name="host2" tabindex="8" placeholder="Enter imap destination server name or IP address">
<datalist id="servers2">
<option value="imap.gmail.com">
<option value="outlook.office365.com">
<option value="imap.mail.yahoo.com">
</datalist>
</div>
<hr /><center>
<button name="button">Start Sync!</button>
</center><hr />
</form>
<?php
    }
?>

<?php
    if (isset($_POST['button']))
    {
        $output = exec('SERVER_SOFTWARE=0 /usr/bin/imapsync --addheader --automap --user1 '.$_POST["user1"].' --password1 '.$_POST["password1"].' --host1 '.$_POST["host1"].'--user2 '.$_POST["user2"].' --password2 '.$_POST["password2"].' --host2 '.$_POST["host2"].'');
        //echo "<pre>$output</pre>";
        //echo $output;
        $status = substr($output, 0, -24);
        $status = substr($status, -1);
        //echo $status;
if ($status == '0') { echo '<center><img height="100" width="100" src="img/success.jpg"><br /><br />Your email account has been successfully synced! You may now go back and sync any additonal accounts.<br /><p><a href="javascript:history.go(-1)" title="Return to previous page">&laquo; Go back</a>'; }
if ($status != '0') { echo '<center><img height="100" width="100" src="img/failed.jpg"><br /><br />An error occured syncing your email account. Please go back and confirm the connection details you have entered.<br /><p><a href="javascript:history.go(-1)" title="Return to previous page">&laquo; Go back</a>'; }


}
?>

<?php
print $cpanel->footer();                      // Add the footer.
$cpanel->end();                               // Disconnect from cPanel - only do this once.
?>
